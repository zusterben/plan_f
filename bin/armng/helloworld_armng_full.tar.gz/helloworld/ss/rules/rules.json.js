{
  "gfwlist": {
    "name": "gfwlist.conf",
    "date": "2026-01-07 14:10",
    "md5": "c7bae4c99bb538ac7036e2865800921b",
    "count": "5601"
  },
  "chnroute": {
    "name": "chnroute.txt",
    "date": "2026-01-07 14:10",
    "md5": "adee981922b1b825bcf67448ed2f1e74",
    "count": "7166",
    "count_ip": "773446841454",
    "source": "ipip",
    "url": "https://github.com/firehol/blocklist-ipsets/blob/master/ipip_country/ipip_country_cn.netset"
  },
  "cdn_china": {
    "name": "cdn.txt",
    "date": "2026-01-07 14:10",
    "md5": "80148c758e782059aedbb6f0b7fbd352",
    "count": "114201"
  }
}
